import getpass
import logging
import os
import secrets
import sys
from pathlib import Path

from pydantic import ValidationError

from agent.agent_loop import AgentStepLimitError, run_readonly_agent
from web.auth import AuthService
from storage.database import Database
from llm.deepseek_api import (
    DeepSeekAPIError,
    DeepSeekConfigurationError,
    DeepSeekNetworkError,
    DeepSeekResponseError,
    DeepSeekSettings,
)
from agent.readonly_tools import ToolArgumentsError, ToolNotAllowedError
from tasks.repository import TaskRepository
from web.schemas import UserCreate
from tasks.service import TaskService


def main() -> int:
    logging.basicConfig(level=logging.INFO, format="%(name)s %(message)s")
    logging.getLogger("httpx").setLevel(logging.WARNING)
    default_db = Path(__file__).with_name("tasks.db").resolve().as_posix()
    database_url = os.getenv("DATABASE_URL", f"sqlite+pysqlite:///{default_db}")
    action = input("操作（1 登录已有账号 / 2 注册新账号）: ").strip()
    if action not in {"1", "2"}:
        print("请选择 1 或 2", file=sys.stderr)
        return 1
    username = input("任务助手用户名: ").strip().lower()
    password = getpass.getpass("任务助手密码: ")
    question = input("问题: ").strip() or "查询我的待完成任务"

    if action == "2":
        try:
            user = UserCreate(username=username, password=password)
        except ValidationError:
            print("注册失败：用户名须为 3～32 字符，密码须为 8～128 字符", file=sys.stderr)
            return 1

    database = Database(database_url)
    try:
        auth = AuthService(
            database.sessions,
            os.getenv("STUDY_TASK_SECRET_KEY") or secrets.token_hex(32),
        )
        if action == "2":
            if auth.register(user.username, user.password) is None:
                print("注册失败：用户名已存在；忘记原密码请换新用户名注册", file=sys.stderr)
                return 1
        token = auth.login(username, password)
        user_id = auth.user_id_for_token(token) if token else None
        if user_id is None:
            print("任务助手用户名或密码错误", file=sys.stderr)
            return 1

        service = TaskService(TaskRepository(database.sessions))
        result = run_readonly_agent(
            question,
            user_id=user_id,
            service=service,
            settings=DeepSeekSettings.from_env(),
        )
    except (
        DeepSeekConfigurationError,
        DeepSeekAPIError,
        DeepSeekNetworkError,
        DeepSeekResponseError,
        AgentStepLimitError,
        ToolArgumentsError,
        ToolNotAllowedError,
    ) as exc:
        print(f"Agent 调用失败: {exc}", file=sys.stderr)
        return 1
    finally:
        database.dispose()

    print(f"回答: {result.answer}")
    print(f"模型请求次数: {result.model_steps}")
    print(f"只读工具调用次数: {result.tool_calls}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
