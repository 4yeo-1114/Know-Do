from knowledge.embedding_retrieval import FastEmbedEmbeddingModel, VectorRetriever
from knowledge.rag import DocumentChunk, KeywordRetriever
from knowledge.retrieval_eval import (
    RetrievalEvalCase,
    compare_retrievers,
    compare_vector_thresholds,
)


CHUNKS = [
    DocumentChunk("proposal.md", 1, "proposal_id 用于防止同一任务提案被重复确认。"),
    DocumentChunk("auth.md", 1, "JWT 用于认证当前用户身份。"),
    DocumentChunk("database.md", 1, "数据库连接池负责复用数据库连接。"),
]


def main() -> None:
    model = FastEmbedEmbeddingModel(model_name="BAAI/bge-small-zh-v1.5")
    retriever = VectorRetriever(CHUNKS, model)
    query = "重复确认会不会重复创建任务？"
    for result in retriever.search(query, limit=2, min_score=0.25):
        print(f"score={result.score:.4f} {result.chunk.source}#{result.chunk.chunk_id}")
        print(result.chunk.text)

    keyword = KeywordRetriever(CHUNKS)
    cases = [
        RetrievalEvalCase("幂等语义", query, ("proposal.md",)),
        RetrievalEvalCase("未知问题", "量子计算如何扩容？", (), expected_empty=True),
    ]
    reports = compare_retrievers(
        {
            "keyword": lambda text, limit: keyword.search(text, limit=limit),
            "embedding": lambda text, limit: retriever.search(
                text, limit=limit, min_score=0.25
            ),
        },
        cases,
        limit=2,
    )
    for name, report in reports.items():
        print(name, f"top_k={report.top_k_hits}/{report.total}",
              f"no_answer={report.no_answer_correct}/{report.no_answer_total}")

    print("threshold comparison:")
    threshold_reports = compare_vector_thresholds(
        retriever, cases, [0.20, 0.25, 0.40, 0.55], limit=2
    )
    for threshold, report in threshold_reports.items():
        print(
            f"min_score={threshold:.2f}",
            f"top_k={report.top_k_hits}/{report.total}",
            f"no_answer={report.no_answer_correct}/{report.no_answer_total}",
            f"sources={[item.actual_sources for item in report.results]}",
        )


if __name__ == "__main__":
    main()

