"""Interactive write proposal: show the model's suggestion before confirmation."""

import getpass
import os
import secrets
import sys

from web.api import get_default_database_url
from web.auth import AuthService
from storage.database import Database
from llm.deepseek_api import (
    DeepSeekAPIError,
    DeepSeekConfigurationError,
    DeepSeekNetworkError,
    DeepSeekResponseError,
    DeepSeekSettings,
)
from agent.readonly_tools import ToolArgumentsError
from tasks.repository import TaskRepository
from tasks.task_proposals import (
    ProposalConflictError,
    ProposalExpiredError,
    TaskProposalService,
    propose_task_from_model,
)


def confirm_preview(preview: dict, *, user_id: int, service: TaskProposalService) -> int | None:
    print(f"待确认提案 ID: {preview['id']}")
    print(f"标题: {preview['title']}")
    print(f"优先级: {preview['priority']}")
    print(f"截止日期: {preview['due_date'] or '无'}")
    choice = input("确认创建任务？输入 yes 才会写入，其他输入将拒绝: ").strip().lower()
    if choice != "yes":
        service.reject(user_id, preview["id"])
        print("已拒绝，任务没有创建")
        return None
    result = service.confirm(user_id, preview["id"])
    task_id = result["task"]["id"]
    print(f"任务已创建，ID: {task_id}")
    return task_id


def main() -> int:
    username = input("任务助手用户名: ").strip().lower()
    password = getpass.getpass("任务助手密码: ")
    question = input("想创建什么任务: ").strip()
    if not question:
        print("任务描述不能为空", file=sys.stderr)
        return 1

    database = Database(get_default_database_url())
    try:
        auth = AuthService(
            database.sessions,
            os.getenv("STUDY_TASK_SECRET_KEY") or secrets.token_hex(32),
        )
        token = auth.login(username, password)
        user_id = auth.user_id_for_token(token) if token else None
        if user_id is None:
            print("任务助手用户名或密码错误", file=sys.stderr)
            return 1

        tasks = TaskRepository(database.sessions)
        print(f"确认前任务数: {len(tasks.list_tasks(user_id))}")
        proposals = TaskProposalService(database.sessions)
        preview = propose_task_from_model(
            question,
            user_id=user_id,
            service=proposals,
            settings=DeepSeekSettings.from_env(),
        )
        confirm_preview(preview, user_id=user_id, service=proposals)
        print(f"结束后任务数: {len(tasks.list_tasks(user_id))}")
        return 0
    except (
        DeepSeekAPIError,
        DeepSeekConfigurationError,
        DeepSeekNetworkError,
        DeepSeekResponseError,
        ToolArgumentsError,
        ProposalConflictError,
        ProposalExpiredError,
        ValueError,
    ) as exc:
        print(f"提案失败: {exc}", file=sys.stderr)
        return 1
    finally:
        database.dispose()


if __name__ == "__main__":
    raise SystemExit(main())
