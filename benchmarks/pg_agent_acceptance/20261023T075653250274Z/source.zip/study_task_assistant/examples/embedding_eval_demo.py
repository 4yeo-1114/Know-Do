import os
from time import perf_counter

from storage.database import Database
from knowledge.embedding_retrieval import FastEmbedEmbeddingModel, VectorRetriever
from storage.pgvector_store import PgVectorConfig, PgVectorRetriever, PgVectorStore
from knowledge.rag import DocumentChunk, KeywordRetriever
from knowledge.retrieval_eval import RetrievalEvalCase, compare_retrievers


CHUNKS = [
    DocumentChunk("proposal.md", 1, "任务提案必须经过用户确认后才能创建任务。"),
    DocumentChunk("auth.md", 1, "JWT 中的 sub 用于识别当前登录用户。"),
    DocumentChunk("rag.md", 1, "向量检索根据问题与文档分块的语义相似度排序。"),
]

CASES = [
    RetrievalEvalCase("提案确认", "创建任务前如何确认提案？", ("proposal.md",)),
    RetrievalEvalCase("用户身份", "JWT 如何识别用户？", ("auth.md",)),
    RetrievalEvalCase("无资料", "量子计算如何扩容？", (), expected_empty=True),
]


def main() -> None:
    url = os.environ["DATABASE_URL"]
    database = Database(url)
    model = FastEmbedEmbeddingModel(threads=1)
    dimension = len(model.encode("维度探测"))
    config = PgVectorConfig(model.model_name, dimension)
    store = PgVectorStore(config)
    owner_id = 1

    with database.sessions.begin() as session:
        store.delete_document(session, owner_id=owner_id, source="proposal.md")
        store.delete_document(session, owner_id=owner_id, source="auth.md")
        store.delete_document(session, owner_id=owner_id, source="rag.md")
        for chunk in CHUNKS:
            store.insert_chunk(
                session,
                owner_id=owner_id,
                chunk=chunk,
                vector=model.encode(chunk.text),
                document_version="eval-v1",
            )

    keyword = KeywordRetriever(CHUNKS)
    memory = VectorRetriever(CHUNKS, model)
    postgres = PgVectorRetriever(database.sessions, model, store)

    def timed(searcher):
        started = perf_counter()
        report = compare_retrievers({"search": searcher}, CASES, limit=1)["search"]
        return report, (perf_counter() - started) * 1000

    retrievers = {
        "keyword": lambda query, limit: keyword.search(query, limit=limit),
        "memory_embedding": lambda query, limit: memory.search(
            query, limit=limit, min_score=0.40
        ),
        "postgres_pgvector": lambda query, limit: postgres.search(
            query, owner_id=owner_id, limit=limit, min_score=0.40
        ),
    }
    for name, searcher in retrievers.items():
        report, milliseconds = timed(searcher)
        passed = sum(result.passed for result in report.results)
        print(
            f"{name}: passed={passed}/{report.total} "
            f"top1={report.top1_hits} topk={report.top_k_hits} "
            f"no_answer={report.no_answer_correct}/{report.no_answer_total} "
            f"elapsed_ms={milliseconds:.1f}"
        )
        for result in report.results:
            print(f"  {result.name}: {result.actual_sources} ({result.details})")

    database.dispose()


if __name__ == "__main__":
    main()
