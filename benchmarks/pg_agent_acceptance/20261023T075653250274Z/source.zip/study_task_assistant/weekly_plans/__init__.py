"""Weekly plan proposal workflow."""
