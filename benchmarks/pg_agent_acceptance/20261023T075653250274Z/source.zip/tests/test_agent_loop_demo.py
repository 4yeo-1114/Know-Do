from types import SimpleNamespace

import examples.agent_loop_demo as agent_loop_demo
from web.auth import AuthService
from storage.database import Database
from storage.migration import upgrade_database

TEST_SECRET = "test-secret-key-at-least-32-bytes"


def test_demo_registers_new_account_then_runs_agent(tmp_path, monkeypatch, capsys):
    url = f"sqlite+pysqlite:///{(tmp_path / 'demo.db').as_posix()}"
    upgrade_database(url)
    monkeypatch.setenv("DATABASE_URL", url)
    answers = iter(["2", "new_agent_user", "查询我的任务"])
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    monkeypatch.setattr(agent_loop_demo.getpass, "getpass", lambda _: "password-123")
    monkeypatch.setattr(agent_loop_demo.DeepSeekSettings, "from_env", lambda: object())
    seen = []

    def fake_agent(question, *, user_id, service, settings):
        seen.append((question, user_id))
        return SimpleNamespace(answer="没有任务", model_steps=2, tool_calls=1)

    monkeypatch.setattr(agent_loop_demo, "run_readonly_agent", fake_agent)
    assert agent_loop_demo.main() == 0
    assert seen == [("查询我的任务", 1)]
    assert "回答: 没有任务" in capsys.readouterr().out

    database = Database(url)
    try:
        auth = AuthService(database.sessions, TEST_SECRET)
        assert auth.login("new_agent_user", "password-123") is not None
    finally:
        database.dispose()


def test_demo_existing_username_does_not_reset_password(tmp_path, monkeypatch, capsys):
    url = f"sqlite+pysqlite:///{(tmp_path / 'demo.db').as_posix()}"
    upgrade_database(url)
    database = Database(url)
    try:
        auth = AuthService(database.sessions, TEST_SECRET)
        assert auth.register("existing_user", "original-password") is not None
    finally:
        database.dispose()

    monkeypatch.setenv("DATABASE_URL", url)
    answers = iter(["2", "existing_user", "查询任务"])
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    monkeypatch.setattr(agent_loop_demo.getpass, "getpass", lambda _: "different-password")
    monkeypatch.setattr(agent_loop_demo, "run_readonly_agent", lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("agent must not run")))
    assert agent_loop_demo.main() == 1
    assert "已存在" in capsys.readouterr().err

    database = Database(url)
    try:
        auth = AuthService(database.sessions, TEST_SECRET)
        assert auth.login("existing_user", "original-password") is not None
        assert auth.login("existing_user", "different-password") is None
    finally:
        database.dispose()


def test_demo_logs_in_with_existing_credentials(tmp_path, monkeypatch):
    url = f"sqlite+pysqlite:///{(tmp_path / 'demo.db').as_posix()}"
    upgrade_database(url)
    database = Database(url)
    try:
        auth = AuthService(database.sessions, TEST_SECRET)
        user = auth.register("existing_user", "original-password")
        assert user is not None
    finally:
        database.dispose()

    monkeypatch.setenv("DATABASE_URL", url)
    answers = iter(["1", "existing_user", "查待完成任务"])
    monkeypatch.setattr("builtins.input", lambda _: next(answers))
    monkeypatch.setattr(agent_loop_demo.getpass, "getpass", lambda _: "original-password")
    monkeypatch.setattr(agent_loop_demo.DeepSeekSettings, "from_env", lambda: object())
    seen = []

    def fake_agent(question, *, user_id, service, settings):
        seen.append((question, user_id))
        return SimpleNamespace(answer="完成", model_steps=2, tool_calls=1)

    monkeypatch.setattr(agent_loop_demo, "run_readonly_agent", fake_agent)
    assert agent_loop_demo.main() == 0
    assert seen == [("查待完成任务", user["id"])]
